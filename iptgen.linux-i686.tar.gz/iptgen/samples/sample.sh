#!/bin/sh

cd `dirname $0`/scripts

ifname=ens33
iptgen=../../bin/iptgen

sudo ${iptgen} --in.file sample.json --out.eth ${ifname}
sudo ${iptgen} --in.file sample.json --out.eth ${ifname}
sudo ${iptgen} --in.file dns-tunnel.json --out.eth ${ifname}
sudo ${iptgen} --in.file ftp-upload.json --out.eth ${ifname}
sudo ${iptgen} --in.file http-upload.json --out.eth ${ifname}
sudo ${iptgen} --in.file https-upload.json --out.eth ${ifname}

${iptgen} --in.file sample.json --out.file ../sample.pcap --pcap.compression 5
${iptgen} --in.file dns-tunnel.json --out.file ..\dns-tunnel.pcap --pcap.compression 5
${iptgen} --in.file ftp-upload.json --out.file ..\ftp-upload.pcap --pcap.compression 5
${iptgen} --in.file http-upload.json --out.file ..\http-upload.pcap --pcap.compression 5
${iptgen} --in.file https-upload.json --out.file ..\https-upload.pcap --pcap.compression 5
