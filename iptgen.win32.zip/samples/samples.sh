#!/bin/sh

cd `dirname $0`/scripts

ifname=ens33
iptgen=../../bin/iptgen

sudo ${iptgen} --in.file samples.json --out.eth ${ifname}
${iptgen} --in.file samples.json --out.file ../samples.pcap --pcap.compression 5
